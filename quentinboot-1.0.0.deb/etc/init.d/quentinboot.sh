#! /bin/sh

### BEGIN INIT INFO
# Provides:          Startup Boot for Quentin Hermes SMEMA Adaptor
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Quentin service
# Description:       Startup and Shutdown for Quentin services
### END INIT INFO

# If you want a command to always run, put it here

# Carry out specific functions when asked to by the system
case "$1" in
  start)
    echo "Starting to monitor Shutdown button"
    /usr/local/bin/shutdown-button.py &
    ;;
  stop)
    echo "Stopping the monitor of the Shutdown button"
    kill $(pgrep -f 'python /usr/local/bin/shutdown-button.py')
    ;;
  *)
    echo "Usage: /etc/init.d/listen-for-shutdown.sh {start|stop}"
    exit 1
    ;;
esac

exit 0
